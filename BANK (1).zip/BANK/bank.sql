-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 22 Jun 2023 pada 18.43
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `header`
--

CREATE TABLE `header` (
  `Nama_Cabang` varchar(35) DEFAULT NULL,
  `Id_Cabang` char(3) NOT NULL,
  `Alamat_Cabang` varchar(50) DEFAULT NULL,
  `Trace` char(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `header`
--

INSERT INTO `header` (`Nama_Cabang`, `Id_Cabang`, `Alamat_Cabang`, `Trace`) VALUES
('I Gusti Ayu Maya', 'cb1', 'Ds. 2 Desa Toto Harjo Lampung Timur Kab', '019288'),
('Toko Fahmi', 'cb2', 'Kc Cibinong Kanwil Jakarta 2', '005119'),
('Toko Putro 3', 'cb3', 'Jl. Tombak No.10 Rt 13 Jakarta Pusat', '013363'),
('Aris Suswanto', 'cb4', 'Villa Mutiara Jaya Blok M Bekasi Kab Jawa Barat ', '003461');

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `nasabah`
--

CREATE TABLE `nasabah` (
  `Id_Nasabah` char(4) NOT NULL,
  `Nama_Nasabah` varchar(25) DEFAULT NULL,
  `No_rekening` char(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `nasabah`
--

INSERT INTO `nasabah` (`Id_Nasabah`, `Nama_Nasabah`, `No_rekening`) VALUES
('1937', 'Anis Maryani', '722910105125539'),
('2763', 'Dwi Silvawati', '129801000040503'),
('4981', 'Surya Fatmawati', '399201009542532'),
('7632', 'M. Jalil Utama', '078001013410533');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rekening`
--

CREATE TABLE `rekening` (
  `No_Rekening` char(15) NOT NULL,
  `Id_Nasabah` char(4) NOT NULL,
  `Nama_Nasabah` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `rekening`
--

INSERT INTO `rekening` (`No_Rekening`, `Id_Nasabah`, `Nama_Nasabah`) VALUES
('078001013410533', '7632', 'M.Jalil Utama'),
('129801000040503', '2763', 'Dwi Silvawati'),
('399201009542532', '4981', 'Surya Fatmawati'),
('722910105125539', '1937', 'Anis Maryani');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `Id_Cabang` char(3) NOT NULL,
  `No_Referensi` char(12) NOT NULL,
  `Id_Nasabah` char(4) NOT NULL,
  `Nama_Nasabah` varchar(25) DEFAULT NULL,
  `No_Rekening` char(15) NOT NULL,
  `Jenis_Transaksi` varchar(10) DEFAULT NULL,
  `Tanggal_Transaksi` date DEFAULT NULL,
  `Jam` time DEFAULT NULL,
  `Terminal_Id` char(8) NOT NULL,
  `Merchant_Id` char(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`Id_Cabang`, `No_Referensi`, `Id_Nasabah`, `Nama_Nasabah`, `No_Rekening`, `Jenis_Transaksi`, `Tanggal_Transaksi`, `Jam`, `Terminal_Id`, `Merchant_Id`) VALUES
('cb4', '000000193231', '1937', 'Anis Maryani', '722910105125539', 'Penarikan', '2019-07-02', '16:01:00', '26150600', '000001370148593'),
('cb2', '000003140128', '7632', 'M. Jalil Utama', '078001013410533', 'Transfer', '2020-08-12', '14:15:00', '26037413', '000001370036257'),
('cb1', '000003814635', '4981', 'Surya Fatmawati', '399201009542532', 'Penarikan', '2018-10-07', '17:47:00', '26187833', '000001370185037'),
('cb3', '000006964029', '2763', 'Dwi Silvawati', '129801000040503', 'Transfer', '2018-04-03', '20:31:00', '26030736', '000001370029644');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `header`
--
ALTER TABLE `header`
  ADD PRIMARY KEY (`Id_Cabang`,`Trace`);

--
-- Indeks untuk tabel `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `nasabah`
--
ALTER TABLE `nasabah`
  ADD PRIMARY KEY (`Id_Nasabah`),
  ADD KEY `Id_Nasabah` (`Id_Nasabah`),
  ADD KEY `Id_Nasabah_2` (`Id_Nasabah`),
  ADD KEY `No_rekening` (`No_rekening`),
  ADD KEY `Nama_Nasabah` (`Nama_Nasabah`);

--
-- Indeks untuk tabel `rekening`
--
ALTER TABLE `rekening`
  ADD PRIMARY KEY (`No_Rekening`),
  ADD KEY `Id_Nasabah` (`Id_Nasabah`),
  ADD KEY `Nama_Nasabah` (`Nama_Nasabah`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`No_Referensi`,`Terminal_Id`,`Merchant_Id`),
  ADD KEY `Id_Nasabah` (`Id_Nasabah`),
  ADD KEY `No_Rekening` (`No_Rekening`),
  ADD KEY `Id_Cabang` (`Id_Cabang`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `nasabah`
--
ALTER TABLE `nasabah`
  ADD CONSTRAINT `nasabah_ibfk_1` FOREIGN KEY (`Id_Nasabah`) REFERENCES `transaksi` (`Id_Nasabah`),
  ADD CONSTRAINT `nasabah_ibfk_2` FOREIGN KEY (`No_rekening`) REFERENCES `rekening` (`No_Rekening`);

--
-- Ketidakleluasaan untuk tabel `rekening`
--
ALTER TABLE `rekening`
  ADD CONSTRAINT `rekening_ibfk_1` FOREIGN KEY (`No_Rekening`) REFERENCES `transaksi` (`No_Rekening`),
  ADD CONSTRAINT `rekening_ibfk_2` FOREIGN KEY (`Id_Nasabah`) REFERENCES `nasabah` (`Id_Nasabah`);

--
-- Ketidakleluasaan untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`Id_Cabang`) REFERENCES `header` (`Id_Cabang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
