<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" href="css/style.css">

    <title>Register Form </title>
</head>

<body style="background-image: 2.jpg;">
    <div class="container">
        <?php         
        error_reporting(0);
        ini_set('display_errors', 0);
        ?>
        <form action="" method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Register</p>
            <div class="input-group">
                <input type="text" placeholder="Username" name="username" value="<?= $data['username'] ?>" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Password" name="password" value="<?= $data['password'] ?>" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Confirm Password" name="cpassword" value="<?= $data['cpassword'] ?>" required>
            </div>
            <div class="input-group">
                <button name="submit" class="btn">Register</button>
            </div>
            <p class="login-register-text">Have an account? <a href="index.php">Login Here</a>.</p>
        </form>
        <?php
        error_reporting(0);
        ini_set('display_errors', 0);
			include 'koneksi.php';
                if (isset($_POST['submit'])) {
                    $sql=mysqli_query($db,"INSERT INTO login(username, password, level) VALUES('$_POST[username]','$_POST[password]','User')");
                    if ($sql) {
                        header('location:index.php'); 
                    }
                }
		?>
    </div>
</body>

</html>