<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>BankQ</title>
  <link rel="stylesheet" href="style4.css" />
  <!-- Font Awesome Cdn Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
</head>

<body>
  <header class="header">
    <div class="logo">
      <a href="#">BankQ</a>
      <div class="search_box">
        <input type="text" placeholder="Search">
        <i class="fa-sharp fa-solid fa-magnifying-glass"></i>
      </div>
    </div>

    <div class="header-icons">
      <i class="fas fa-bell"></i>
      <div class="account">
        <img src="../BANK.jpg" alt="">
      </div>
    </div>
  </header>
  <div class="container">
    <nav>
      <div class="side_navbar">
        <span>Main Menu</span>
        <a href="page1.php">Dashboard</a>
        <a href="page2.php" class="active">Nasabah</a>
        <a href="page3.php">Transaksi</a>
        <a href="page4.php">Rekening</a>

        <i><a href="../logout.php">Log Out</a>
        </i>
    </nav>
    <section class="attendance">
      <div class="attendance-list">
        <h2>Data Nasabah</h2>
        <button>
          <a href="../proses/nasabah/create.php">Tambah Data</a>
        </button>
        <table class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>ID</th>
              <th>Nasabah</th>
              <th>Rekening</th>
              <th>Date</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            <?php
              include '../koneksi.php';
                $ambil=mysqli_query($db,"SELECT * FROM nasabah");
              $no=1;
              while ($data = mysqli_fetch_array($ambil)){
            ?>
            <tr>
              <td><?php echo $no ?></td>
              <td><?php echo $data ['Id_Nasabah']; ?></td>
              <td><?php echo $data ['Nama_Nasabah']; ?></td>
              <td><?php echo $data ['No_rekening']; ?></td>
              <td><?php echo $data ["Tanggal_Transaksi"]; ?></td>
              <td>
                <button>
                  <a href="../proses/nasabah/edit.php?Id_Nasabah=<?= $data['Id_Nasabah'] ?> ">Edit</a>
                </button>
                <button>
                  <a href="../proses/nasabah/delete.php?Id_Nasabah=<?= $data['Id_Nasabah'] ?> "onclick="return confirm ('Yakin Menghapus Data ?')">Delete</a>
                </button>
              </td>
            </tr>
            <?php 
              $no++; 
            }
            ?>
          </tbody>
        </table>
      </div>
    </section>

  </div>
  </div>
  </div>
</body>

</html>