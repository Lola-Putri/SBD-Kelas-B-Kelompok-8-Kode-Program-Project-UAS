<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" href="../style.css">

    <title>Tambah Data</title>
</head>

<body style="background-image: 2.jpg;">
    <div class="container">
        <?php         
        error_reporting(0);
        ini_set('display_errors', 0);
        ?>
        <form action="" method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Tambah Data</p>
            <div class="input-group">
                <input type="text" placeholder="Id Nasabah" name="id" required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="Nama Nasabah" name="nama" required>
            </div>
            <div class="input-group">
                <input type="number" placeholder="No Rekening" name="no"  required>
            </div>
            <div class="input-group">
                <input type="date" placeholder="date" name="Tanggal"  required>
            </div>
            <div class="input-group">
                <button type="submit" class="btn" name="submit">Tambah Data</button>
            </div>
            <div class="input-group">
                <button type="reset" class="btn">Reset</button>
            </div>
        </form>
        <?php
        // error_reporting(0);
        // ini_set('display_errors', 0);
			include 'koneksi.php';
                if (isset($_POST['submit'])) {
                    $sql=mysqli_query($db,"INSERT INTO nasabah(Id_Nasabah,Nama_Nasabah,No_rekening,Tanggal_Transaksi) VALUES('$_POST[id]','$_POST[nama]','$_POST[no]','$_POST[Tanggal]')");
                    if ($sql) {
                        header('location:../../model/page2.php');
                    }

                }
		?>
    </div>
</body>

</html>