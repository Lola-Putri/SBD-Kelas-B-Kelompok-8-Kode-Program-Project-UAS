<?php
  include 'koneksi.php';
  $hapus=mysqli_query($db,"DELETE FROM nasabah WHERE Id_Nasabah = $_GET[Id_Nasabah]");
  if($hapus){
    header('location:../../model/page2.php');
  }
?>
    