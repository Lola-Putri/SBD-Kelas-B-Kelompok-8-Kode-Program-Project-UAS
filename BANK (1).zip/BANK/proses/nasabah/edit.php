<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" href="../style.css">

    <title>Edit Data</title>
</head>

<body style="background-image: 2.jpg;">
    <div class="container">
        <?php         
        error_reporting(0);
        ini_set('display_errors', 0);
        ?>
        <form action="" method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Edit Data</p>
            <div class="input-group">
                <input type="text" placeholder="Id Nasabah" name="id" required>
            </div>
            <div class="input-group">
                <input type="text" placeholder="Nama Nasabah" name="nama" required>
            </div>
            <div class="input-group">
                <input type="number" placeholder="No Rekening" name="no"  required>
            </div>
            <div class="input-group">
                <input type="date" placeholder="date" name="Tanggal Transaksi"  required>
            </div>
            <div class="input-group">
                <button type="submit" class="btn" name="submit">Edit</button>
            </div>
            <div class="input-group">
                <button type="reset" class="btn">Cancel</button>
            </div>
        </form>
        <?php
			include 'koneksi.php';
                if (isset($_POST['submit'])) {
                    $sql=mysqli_query($db,"UPDATE nasabah SET
                    Id_Nasabah        ='$_POST[Id_Nasabah]',
                    Nama_Nasabah      ='$_POST[Nama_Nasabah]',
                    No_rekening       ='$_POST[No_rekening]',;
                    Tanggal_Transaksi ='$_Post[Tanggal_Transaksi]'"
                    );
                    if ($sql) {
                        header('location: ../../model/page.php');
                        exit;
                    }

                }
		?>
    </div>
</body>

</html>