<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" href="css/style.css">

	<title>Login Bank</title>
</head>
<body>
	<div class="container">
		<form action="" method="POST" class="login-email">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;">Login</p>
			<div class="input-group">
				<input type="text" placeholder="Nasabah" name="username" required>
			</div>
			<div class="input-group">
				<input type="password" placeholder="Password" name="password" required>
			</div>
			<div class="input-group">
			<button class="btn" type="submit" name="submit">Log in</button>
			</div>
			<p class="login-register-text">Don't have an account? <a href="register.php">Register Here</a>.</p>
		</form>
        <?php
        error_reporting(0);
        ini_set('display_errors', 0);
			include 'koneksi.php';
			if (isset($_POST['submit'])) {
				$login=mysqli_query($db,"SELECT * FROM login WHERE username ='$_POST[username]' AND password='$_POST[password]'");
				$hasil_login=mysqli_num_rows($login);
                $data_login=mysqli_fetch_array($login);
					if ($hasil_login>0) {
						session_start();
                        $_SESSION['level'] = $data_login['level'];
                        if ($_SESSION['level']=='Admin') {
						header('location:model/page1.php');
                        }else{
							header('location:model/page1.php');
						}
						
                        
					}
			}
		?>
	</div>
</body>
</html>
