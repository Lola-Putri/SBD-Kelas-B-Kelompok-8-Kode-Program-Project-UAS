<div class="modal fade" nasabah="edit_<?php echo $row['nasabah']; ?>" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ModalLabel">Edit Membe</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="edit.php?id=<?php echo $row['nasabah']; ?>">
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label">Id Nasabah</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Id Nasabah" value="<?php echo $row['Id_Nasabah']; ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label">Nama Nasabah</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Nama Nasabah" value="<?php echo $row['Nama_Nasabah']; ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label">No Rekening</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="No Rekening" value="<?php echo $row['No_Rekening']; ?>">
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="edit" class="btn btn-primary"> Update</a>
                    </form>
            </div>
        </div>
    </div>
</div>