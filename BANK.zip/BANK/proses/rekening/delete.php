<?php
include "koneksi.php";
$no_rekening = $_GET[no_rekening];
$sql = "DELETE FROM `rekening` WHERE no_rekening = $no_rekening";
$result = mysqli_query($conn, $sql);

  if (isset($_POST['submit'])) {
  $sql=mysqli_query($bank,"DELETE FROM rekening(No_rekening,Id_Nasabah,Nama_Nasabah) VALUES('$_POST[No_Rekening]','$_POST[Id_Nasabah]','$_POST[Nama_Nasabah]')");
  if ($sql) {
    header('location:../../model/page4.php');
     }

    }