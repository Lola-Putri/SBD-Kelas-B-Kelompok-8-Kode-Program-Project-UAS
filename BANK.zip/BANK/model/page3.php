<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>BankQ</title>
    <link rel="stylesheet" href="style4.css" />
    <!-- Font Awesome Cdn Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
</head>

<body>
    <header class="header">
        <div class="logo">
            <a href="#">BankQ</a>
            <div class="search_box">
                <input type="text" placeholder="Search">
                <i class="fa-sharp fa-solid fa-magnifying-glass"></i>
            </div>
        </div>

        <div class="header-icons">
            <i class="fas fa-bell"></i>
            <div class="account">
                <img src="../BANK.jpg" alt="">
            </div>
        </div>
    </header>
    <div class="container">
        <nav>
            <div class="side_navbar">
                <span>Main Menu</span>
                <a href="page1.php">Dashboard</a>
                <a href="page2.php">Nasabah</a>
                <a href="page3.php" class="active">Transaksi</a>
                <a href="#">Rekening</a>

                <i><a href="../logout.php">Log Out</a>
                </i>
        </nav>
        <section class="attendance">
            <div class="attendance-list">
                <h2>Data Transaksi</h2>
                <button>
                    <a href="proses/nasabah/create.php">Tambah Data</a>
                </button>
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Id Cabang</th>
                            <th>No Referensi</th>
                            <th>Id Nasabah</th>
                            <th>Nama Nasabah</th>
                            <th>No Rekening</th>
                            <th>Jenis Transaksi</th>
                            <th>Tanggal</th>
                            <th>Jam</th>
                            <th>Terminal Id</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>cb1</td>
                            <td>000003814635</td>
                            <td>4981</td>
                            <td>Surya Fatmawati</td>
                            <td>399201009542532</td>
                            <td>Penarikan</td>
                            <td>07-10-2018</td>
                            <td>17:47</td>
                            <td>26187833</td>
                            <td>
                                <button>
                                    <a href="#">Ubah</a>
                                </button>
                                <button>
                                    <a href="#">Delete</a>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>cb2</td>
                            <td>000003140128</td>
                            <td>7632</td>
                            <td>M Jalil Utama</td>
                            <td>078001013410533</td>
                            <td>Transfer</td>
                            <td>12-08-2020</td>
                            <td>14:15</td>
                            <td>26037413</td>
                            <td><button>
                                    <a href="#">Ubah</a>
                                </button>
                                <button>
                                    <a href="#">Delete</a>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>cb3</td>
                            <td>000006964029</td>
                            <td>2763</td>
                            <td>Dwi Silvawati</td>
                            <td>129801000040503</td>
                            <td>Tranfer</td>
                            <td>03-04-2018</td>
                            <td>20:31</td>
                            <td>26030736</td>
                            <td><button>
                                    <a href="#">Ubah</a>
                                </button>
                                <button>
                                    <a href="#">Delete</a>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>cb4</td>
                            <td>000000193231</td>
                            <td>1937</td>
                            <td>Anis Maryani</td>
                            <td>722910105125539</td>
                            <td>Penarikan</td>
                            <td>02-07-2019</td>
                            <td>16:01</td>
                            <td>26150600</td>
                            <td><button>
                                    <a href="#">Ubah</a>
                                </button>
                                <button>
                                    <a href="#">Delete</a>
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</body>

</html>