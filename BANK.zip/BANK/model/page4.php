<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>BankQ</title>
    <link rel="stylesheet" href="style4.css" />
    <!-- Font Awesome Cdn Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
</head>

<body>
    <header class="header">
        <div class="logo">
            <a href="#">BankQ</a>
            <div class="search_box">
                <input type="text" placeholder="Search">
                <i class="fa-sharp fa-solid fa-magnifying-glass"></i>
            </div>
        </div>

        <div class="header-icons">
            <i class="fas fa-bell"></i>
            <div class="account">
                <img src="../BANK.jpg" alt="">
            </div>
        </div>
    </header>
    <div class="container">
        <nav>
            <div class="side_navbar">
                <span>Main Menu</span>
                <a href="page1.php">Dashboard</a>
                <a href="page2.php">Nasabah</a>
                <a href="page3.php">Transaksi</a>
                <a href="page4.php"class="active">Rekening</a>

                <i><a href="../logout.php">Log Out</a>
                </i>
        </nav>
        <section class="attendance">
            <div class="attendance-list">
                <h2>Data Transaksi</h2>
                <button>
                    <a href="index.php">Tambah Data</a>
                </button>
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>No Rekening</th>
                            <th>Id Nasabah</th>
                            <th>Nama Nasabah</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>399201009542532</td>
                            <td>4981</td>
                            <td>Surya Fatmawati</td>
                            <td>
                                <button>
                                    <a href="proses/rekening/edit.php">Ubah</a>
                                </button>
                                <button>
                                    <a href="proses/rekening/delete.php">Delete</a>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>078001013410533</td>
                            <td>7632</td>
                            <td>M Jalil Utama</td>
                            <td><button>
                                    <a href="proses/rekening/edit.php">Ubah</a>
                                </button>
                                <button>
                                    <a href="proses/rekening/delete.php">Delete</a>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>129801000040503</td>
                            <td>2763</td>
                            <td>Dwi Silvawati</td>
                            <td><button>
                                    <a href="proses/rekening/edit.php">Ubah</a>
                                </button>
                                <button>
                                    <a href="proses/rekening/delete.php">Delete</a>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>722910105125539</td>
                            <td>1937</td>
                            <td>Anis Maryani</td>
                            <td><button>
                                    <a href="proses/rekening/edit.php">Ubah</a>
                                </button>
                                <button>
                                    <a href="proses/rekening/delete.php">Delete</a>
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</body>

</html>