<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>BankQ</title>
    <link rel="stylesheet" href="style4.css" />
    <!-- Font Awesome Cdn Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
</head>

<body>
    <header class="header">
        <div class="logo">
            <a href="#">BankQ</a>
            <div class="search_box">
                <input type="text" placeholder="Search">
                <i class="fa-sharp fa-solid fa-magnifying-glass"></i>
            </div>
        </div>

        <div class="header-icons">
            <i class="fas fa-bell"></i>
            <div class="account">
                <img src="../BANK.jpg" alt="">
            </div>
        </div>
    </header>
    <div class="container">
        <nav>
            <div class="side_navbar">
                <span>Main Menu</span>
                <a href="page1.php" class="active">Dashboard</a>
                <a href="page2.php">Nasabah</a>
                <a href="page3.php">Transaksi</a>
                <a href="#">Rekening</a>

                <i><a href="../logout.php">Log Out</a>
                </i>
        </nav>

        <div class="main-body">
            <h2>Dashboard</h2>
            <div class="promo_card">
                <h1>Welcome to BankQ</h1>
                <button>Learn More</button>
            </div>

            <div class="history_lists">
                <div class="list1">
                    <div class="row">
                        <h4>Transaksi</h4>
                        <a href="#">See all</a>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Tanggal</th>
                                <th>Id Nasabah</th>
                                <th>Nama Nasabah</th>
                                <th>No Rekening</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>07 November 2018 </td>
                                <td>4981</td>
                                <td>Surya Fatamwati</td>
                                <td>399201009542532</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>12 Agustus 2020</td>

                                <td>7632</td>
                                <td>M Jalil Utama</td>
                                <td>078001013410533</td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>03 April 2018</td>

                                <td>2763</td>
                                <td>Dwi Silvawati</td>
                                <td>129801000040503</td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>02 Juli 2019</td>
                                <td>1937</td>
                                <td>Anis Maryani</td>
                                <td>722910105125539</td>
                            </tr>
                            <!--<tr>
                                <td>5</td>
                                <td>29, June, 2022</td>
                                <td>Gomiz</td>
                                <td>Gold</td>
                                <td>$4000.00</td>
                            </tr>
                            <tr>
                                <td>6</td>
                                <td>28, June, 2022</td>
                                <td>Elyana Jhon</td>
                                <td>Premimum</td>
                                <td>$2000.00</td>
                            </tr>-->
                        </tbody>
                    </table>
                </div>

                <div class="list2">
                    <div class="row">
                        <h4>Documnets</h4>
                        <a href="#">Upload</a>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Id Cabang</th>
                                <th>Nama Cabang</th>
                                <th>Trace</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>cb1</td>
                                <td>I Gusti Ayu Maya</td>
                                <td>019288</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>cb2</td>
                                <td>Toko Fahmi</td>
                                <td>005119</td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>cb3</td>
                                <td>Toko putro 3</td>
                                <td>013363</td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>cb4</td>
                                <td>Aris Suswanto</td>
                                <td>003461</td>
                            </tr>
                            <!--tr>
                                <td>5</td>
                                <td>CNIC</td>
                                <td>Jpg</td>
                                <td>22</td>
                            </tr>
                            <tr>
                                <td>6</td>
                                <td>Docx</td>
                                <td>Word</td>
                                <td>22</td>
                            </tr>-->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>

</html>