<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" href="css/style.css">

	<title>Tambah Data</title>
</head>
<body>
	<div class="container">
		<form action="" method="POST" class="login-email">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;">Tambah Data</p>
			<div class="input-group">
				<input type="text" placeholder="Nomor" name="no_rekening" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="ID" name="id_nasabah" required>
			</div>
            <div class="input-group">
				<input type="text" placeholder="Nama" name="nama_nasabah" required>
			</div>
			<div class="input-group">
			<button class="btn" type="submit" name="submit">Tambah</button>
			</div>
		</form>
        <?php
        error_reporting(0);
        ini_set('display_errors', 0);
			include 'koneksi.php';
			if (isset($_POST['submit'])) {
				$Tambah=mysqli_query($db,"SELECT * FROM Tambah WHERE Nomor ='$_POST[no_rekening]', Nomor='$_POST[ID]' AND Nama='$_POST[Nama]'");
				$hasil_tambah=mysqli_num_rows($tambah);
                $data_tambah=mysqli_fetch_array($tambah);
					if ($hasil_tambah>0) {
						session_start();
                        $_SESSION['level'] = $data_tambah['level'];
                        if ($_SESSION['level']=='Admin') {
						header('location:model/page4.php');
                        }else{
							header('location:model/page4.php');
						}
						
                        
					}
			}
		?>
	</div>
</body>
</html>