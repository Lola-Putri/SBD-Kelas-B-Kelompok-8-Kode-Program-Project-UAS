<?php
// Menghubungkan ke database
$koneksi = mysqli_connect("localhost", "username", "password", "bank");

// Memeriksa koneksi database
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Mendapatkan ID data yang akan diubah
$id = $_GET['id'];

// Menampilkan data yang akan diubah
$query = mysqli_query($koneksi, "SELECT * FROM rekening WHERE id = '$id'");
$data = mysqli_fetch_assoc($query);

// Memproses perubahan data
if (isset($_POST['submit'])) {
    $Rekening = $_POST['no_rekening'];
    $IdN = $_POST['id_nasabah'];
    $nama = $_POST['nama'];

    $query = mysqli_query($koneksi, "UPDATE  SET no_rekening = '$Rekening', id_nasabah = '$IdN', nama ='$nama' WHERE id = '$id'");
    
    if ($query) {
        echo "Data berhasil diubah.";
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
?>

<form method="POST" action="">
    <label for="Rekening">Rekening:</label>
    <input type="text" name="no_rekening" value="<?php echo $data['no_rekening']; ?>" required><br>

    <label for="Id">Id:</label>
    <input type="text" name="id_nasabah" value="<?php echo $data['id_nasabah']; ?>" required><br>

    <label for="nama">nama:</label>
    <input type="text" name="nama" value="<?php echo $data['nama_nasabah']; ?>" required><br>

    <input type="submit" name="submit" value="Ubah Data">
</form>
