<?php
include_once "koneksi.php";
$id=$_POST[no_rekening];
$idnasabah=$_POST[id_nasabah];
$nama_nasabah=$_POST[nama_nasabah];
mysqli_query($connect,"UPDATE rekening SET  id_nasabah='$id_nasabah', nama_nasabah='$nama_nasabah' where no_rekening=$id");
header("Location:rekening.php");
?>