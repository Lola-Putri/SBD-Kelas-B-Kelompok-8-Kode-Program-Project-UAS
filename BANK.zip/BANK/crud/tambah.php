<html>
    <head><title>Tambah Data</title></head>
    <body>
        <h1>Tambah Data</h1>
        <form action="tambahproses.php" method="post" name="input">
            No Rekening : <input type="text" name="no_rekening"> <br>
            Id Nasabah  : <input type="text" name="id_nasabah"> <br>
            Nama Nasabah  : <input type="text" name="nama_nasabah"> <br>
            <input type="submit" value="Tambah">
            <a href="rekening.php">Batal</a>
        </form>
    </body>
</html>
            