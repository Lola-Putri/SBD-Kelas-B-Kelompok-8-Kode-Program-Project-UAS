<html>
    <head><title>Edit Data</title></head> 
    <body>
        <?php
        include "koneksi.php";
        $id=$_GET[no_rekening];
        $data=mysqli_query($connect,"SELECT *FROM rekening where no_rekening=$id");
        $d=mysqli_fetch_array($data);
        ?>
        <h1>Edit Data</h1>
        <form method="post" action="editproses.php">
            Id Nasabah : <input type="text" name="id_nasabah" value="<?=$id[id_nasabah]?>"> <br>
            Nama Nasabah : <input type="text" name="nama_nasabah" value="<?=$id[nama_nasabah]?>"> <br>
            <input type="hidden" name="id" value="<?$d[no_rekening]?>">
            <input type="submit" value="Edit">
            <a href="rekening.php">Batal</a>
        </form>
    </body>
</html>
            