<?phpinclude "koneksi.php";

$query= "SELECT FROM rekening";
$hasil= mysqli_query($connect,$query);

echo "Data Rekening Nasabah : <br>";
echo "<a href='tambah.php'>Tambah Data</a> <br>";
while($data=mysqli_fetch_array($hasil)){
    echo $data[no_rekening]. $data[id_nasabah] $data[nama_nasabah]::;
    echo </a href='edit.php?id=$data[no_rekening]'>Edit</a> |
    </a href='hapus.php?=$data[no_rekening]'>Hapus</a> <br>;

}
?>