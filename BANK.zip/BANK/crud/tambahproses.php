<?php
include_once "koneksi.php";
$id_nasabah=$_POST[id_nasabah];
$nama_nasabah=$_POST[nama_nasabah];
$result=mysqli_query($connect,"INSERT INTO rekening(id_nasabah,nama_nasabah VALUES($id_nasabah, $nama_nasabah)");
header("Location:rekening.php");
?>