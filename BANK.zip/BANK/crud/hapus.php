<?php
include "koneksi.php";
$id=$_GET['no_rekening'];
mysqli_query($connect, "DELETE FROM rekening where no_rekening = '$id'");
header("Location:rekening.php");
?>