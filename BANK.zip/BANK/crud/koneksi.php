<?php
$server="localhost";
$username="root";
$password="";
$database="bank";

$connect=mysqli_connect($server,$username,$password,$database) or die("Koneksi gagal");