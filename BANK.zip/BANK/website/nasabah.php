<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>BANK</title>
  <link rel="stylesheet" href="style2.css" />
  <!-- Font Awesome Cdn Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />

  <link rel="stylesheet" href="style2.css">
</head>

<body>
  <div class="container">
    <nav>
      <ul>
        <li><a href="#" class="logo">
            <img src="logo.jpg">
            <span class="nav-item">BANK</span>
          </a></li>
        <li><a href="#">
            <i class="fas fa-home"></i>
            <span class="nav-item">DASHBOARD</span>
          </a>
        </li>
        <li>
          <a href="#">
            <i class="fas fa-user"></i>
            <span class="nav-item">NASABAH</span>
          </a>
        </li>
        <li><a href="#">
            <i class="fas fa-wallet"></i>
            <span class="nav-item">REKENING</span>
          </a></li>
        <li><a href="#">
            <i class="fas fa-chart-line"></i>
            <span class="nav-item">TRANSAKSI</span>
          </a></li>
        <li><a href="#">
            <i class="fas fa-cog"></i>
            <span class="nav-item">Setting</span>
          </a></li>

        <li><a href="../logout.php" class="logout">
            <i class="fas fa-sign-out-alt"></i>
            <span class="nav-item">Log out</span>
          </a></li>
      </ul>
    </nav>
    <div class="main">
      <div class="head">
        <div class="haed-title">
          <h2>Nasabah</h2>
        </div>
        <div class="head-search">
          <input type="search" placeholder="Search">
        </div>
      </div>
      <section class="attendance">
        <div class="attendance-list">
          <h2>Data Nasabah</h2>
          <table class="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nasabah</th>
                <th>Rekening</th>
                <th>Date</th>
                <th>Referensi</th>
                <th>Jenis Transaksi</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1937</td>
                <td>Anis Maryani</td>
                <td>722910105125539</td>
                <td>02-07-2019</td>
                <td>000000193231</td>
                <td>Penarikan</td>
                <td><button>View</button></td>
              </tr>
              <tr>
                <td>7632</td>
                <td>M Jalil Utama</td>
                <td>078001013410533</td>
                <td>12-08-2020</td>
                <td>000003140128</td>
                <td>Transfer</td>
                <td><button>View</button></td>
              </tr>
              <tr>
                <td>4981</td>
                <td>Surya Fatmawati</td>
                <td>399201009542532</td>
                <td>07-10-2018</td>
                <td>000003814635</td>
                <td>Penarikan</td>
                <td><button>View</button></td>
              </tr>
              <tr>
                <td>2763</td>
                <td>Dwi Silvawati</td>
                <td>129801000040503</td>
                <td>03-04-2018</td>
                <td>000006964029</td>
                <td>Transfer</td>
                <td><button>View</button></td>
              </tr>
              <!-- <tr >
                <td>05</td>
                <td>Salina</td>
                <td>Coding</td>
                <td>03-24-22</td>
                <td>9:00AM</td>
                <td>4:00PM</td>
                <td><button>View</button></td>
              </tr>
              <tr >
                <td>06</td>
                <td>Tara Smith</td>
                <td>Testing</td>
                <td>03-24-22</td>
                <td>9:00AM</td>
                <td>4:00PM</td>
                <td><button>View</button></td>
              </tr> -->
            </tbody>
          </table>
        </div>
      </section>
    </div>
  </div>
</body>

</html>